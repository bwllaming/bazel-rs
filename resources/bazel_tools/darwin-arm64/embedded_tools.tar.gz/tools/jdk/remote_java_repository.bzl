# Copyright 2023 The Bazel Authors. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Redirect symbols from rules_java to keep backward-compatibility."""

load("@rules_java//toolchains:remote_java_repository.bzl", _remote_java_repository = "remote_java_repository")

def remote_java_repository(name, **kwargs):
    _remote_java_repository(name, **kwargs)
    native.register_toolchains("@" + name + "_toolchain_config_repo//:all")
